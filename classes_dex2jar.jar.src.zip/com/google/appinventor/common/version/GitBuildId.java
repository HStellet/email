package com.google.appinventor.common.version;

public final class GitBuildId
{
  public static final String ACRA_URI = "${acra.uri}";
  public static final String ANT_BUILD_DATE = "January 8 2018";
  public static final String GIT_BUILD_FINGERPRINT = "3a1a07bdfdf05c021fcab878cac941d4ebdb3966";
  public static final String GIT_BUILD_VERSION = "nb165";
  
  public static String getAcraUri()
  {
    if ("${acra.uri}".equals("${acra.uri}")) {
      return "";
    }
    return "${acra.uri}".trim();
  }
  
  public static String getDate()
  {
    return "January 8 2018";
  }
  
  public static String getFingerprint()
  {
    return "3a1a07bdfdf05c021fcab878cac941d4ebdb3966";
  }
  
  public static String getVersion()
  {
    String str = "nb165";
    if ((str == "") || (str.contains(" "))) {
      str = "none";
    }
    return str;
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.common.version.GitBuildId
 * JD-Core Version:    0.7.0.1
 */