package com.google.appinventor.components.runtime;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.google.appinventor.components.runtime.util.HoneycombUtil;
import com.google.appinventor.components.runtime.util.SdkLevel;

public class ScaledFrameLayout
  extends ViewGroup
{
  private int mLeftWidth;
  private int mRightWidth;
  private float mScale = 1.0F;
  private final Rect mTmpChildRect = new Rect();
  private final Rect mTmpContainerRect = new Rect();
  
  public ScaledFrameLayout(Context paramContext)
  {
    super(paramContext);
  }
  
  public ScaledFrameLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public ScaledFrameLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    setClipChildren(false);
  }
  
  private void updatePadding(int paramInt1, int paramInt2)
  {
    setPadding(0, 0, (int)(paramInt1 * (this.mScale - 1.0F) / this.mScale), (int)(paramInt2 * (this.mScale - 1.0F) / this.mScale));
  }
  
  protected void dispatchDraw(Canvas paramCanvas)
  {
    paramCanvas.save(1);
    paramCanvas.scale(this.mScale, this.mScale);
    super.dispatchDraw(paramCanvas);
    paramCanvas.restore();
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent)
  {
    paramMotionEvent.setLocation(paramMotionEvent.getX() * (1.0F / this.mScale), paramMotionEvent.getY() * (1.0F / this.mScale));
    super.dispatchTouchEvent(paramMotionEvent);
    return true;
  }
  
  public ViewParent invalidateChildInParent(int[] paramArrayOfInt, Rect paramRect)
  {
    int[] arrayOfInt = new int[2];
    arrayOfInt[0] = ((int)(paramArrayOfInt[0] * this.mScale));
    arrayOfInt[1] = ((int)(paramArrayOfInt[1] * this.mScale));
    Rect localRect = new Rect((int)(paramRect.left * this.mScale), (int)(paramRect.top * this.mScale), (int)(paramRect.right * this.mScale), (int)(paramRect.bottom * this.mScale));
    invalidate(localRect);
    return super.invalidateChildInParent(arrayOfInt, localRect);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = getChildCount();
    int j = getPaddingLeft();
    int k = getPaddingTop();
    int m = paramInt4 - paramInt2 - getPaddingBottom();
    for (int n = 0; n < i; n++)
    {
      View localView = getChildAt(n);
      if (localView.getVisibility() != 8)
      {
        int i1 = localView.getMeasuredWidth();
        int i2 = localView.getMeasuredHeight();
        this.mTmpContainerRect.left = j;
        this.mTmpContainerRect.right = j;
        j = this.mTmpContainerRect.right;
        this.mTmpContainerRect.top = k;
        this.mTmpContainerRect.bottom = m;
        Gravity.apply(51, i1, i2, this.mTmpContainerRect, this.mTmpChildRect);
        localView.layout(this.mTmpChildRect.left, this.mTmpChildRect.top, this.mTmpChildRect.right, this.mTmpChildRect.bottom);
      }
    }
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i = getChildCount();
    this.mLeftWidth = 0;
    this.mRightWidth = 0;
    int j = 0;
    int k = 0;
    for (int m = 0; m < i; m++)
    {
      View localView = getChildAt(m);
      if (localView.getVisibility() != 8)
      {
        measureChild(localView, paramInt1, paramInt2);
        this.mLeftWidth += Math.max(0, localView.getMeasuredWidth());
        j = Math.max(j, localView.getMeasuredHeight());
        if (SdkLevel.getLevel() >= 11) {
          k = HoneycombUtil.combineMeasuredStates(this, k, HoneycombUtil.getMeasuredState(localView));
        }
      }
    }
    int n = 0 + (this.mLeftWidth + this.mRightWidth);
    int i1 = Math.max(j, getSuggestedMinimumHeight());
    int i2 = Math.max(n, getSuggestedMinimumWidth());
    if (SdkLevel.getLevel() >= 11)
    {
      setMeasuredDimension(HoneycombUtil.resolveSizeAndState(this, i2, paramInt1, k), HoneycombUtil.resolveSizeAndState(this, i1, paramInt2, k << 16));
      return;
    }
    setMeasuredDimension(resolveSize(i2, paramInt1), resolveSize(i1, paramInt2));
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    updatePadding(paramInt1, paramInt2);
  }
  
  public void setScale(float paramFloat)
  {
    this.mScale = paramFloat;
    updatePadding(getWidth(), getHeight());
  }
  
  public boolean shouldDelayChildPressedState()
  {
    return false;
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.ScaledFrameLayout
 * JD-Core Version:    0.7.0.1
 */