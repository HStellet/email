package com.google.appinventor.components.runtime;

import android.view.MenuItem;

public abstract interface OnOptionsItemSelectedListener
{
  public abstract boolean onOptionsItemSelected(MenuItem paramMenuItem);
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.OnOptionsItemSelectedListener
 * JD-Core Version:    0.7.0.1
 */