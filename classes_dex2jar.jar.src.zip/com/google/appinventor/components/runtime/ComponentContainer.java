package com.google.appinventor.components.runtime;

import android.app.Activity;

public abstract interface ComponentContainer
{
  public abstract void $add(AndroidViewComponent paramAndroidViewComponent);
  
  public abstract Activity $context();
  
  public abstract Form $form();
  
  public abstract int Height();
  
  public abstract int Width();
  
  public abstract void setChildHeight(AndroidViewComponent paramAndroidViewComponent, int paramInt);
  
  public abstract void setChildWidth(AndroidViewComponent paramAndroidViewComponent, int paramInt);
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.ComponentContainer
 * JD-Core Version:    0.7.0.1
 */