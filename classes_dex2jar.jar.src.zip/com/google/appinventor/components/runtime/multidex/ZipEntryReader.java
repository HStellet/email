package com.google.appinventor.components.runtime.multidex;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;

class ZipEntryReader
{
  private static final long CENSIG = 33639248L;
  private static final int GPBF_ENCRYPTED_FLAG = 1;
  private static final int GPBF_UNSUPPORTED_MASK = 1;
  static final Charset UTF_8 = Charset.forName("UTF-8");
  
  private static long getTime(int paramInt1, int paramInt2)
  {
    GregorianCalendar localGregorianCalendar = new GregorianCalendar();
    localGregorianCalendar.set(14, 0);
    localGregorianCalendar.set(1980 + (0x7F & paramInt2 >> 9), -1 + (0xF & paramInt2 >> 5), paramInt2 & 0x1F, 0x1F & paramInt1 >> 11, 0x3F & paramInt1 >> 5, (paramInt1 & 0x1F) << 1);
    return localGregorianCalendar.getTime().getTime();
  }
  
  static ZipEntry readEntry(ByteBuffer paramByteBuffer)
    throws IOException
  {
    if (paramByteBuffer.getInt() != 33639248L) {
      throw new ZipException("Central Directory Entry not found");
    }
    paramByteBuffer.position(8);
    int i = 0xFFFF & paramByteBuffer.getShort();
    if ((i & 0x1) != 0) {
      throw new ZipException("Invalid General Purpose Bit Flag: " + i);
    }
    int j = 0xFFFF & paramByteBuffer.getShort();
    int k = 0xFFFF & paramByteBuffer.getShort();
    int m = 0xFFFF & paramByteBuffer.getShort();
    long l1 = 0xFFFFFFFF & paramByteBuffer.getInt();
    long l2 = 0xFFFFFFFF & paramByteBuffer.getInt();
    long l3 = 0xFFFFFFFF & paramByteBuffer.getInt();
    int n = 0xFFFF & paramByteBuffer.getShort();
    int i1 = 0xFFFF & paramByteBuffer.getShort();
    int i2 = 0xFFFF & paramByteBuffer.getShort();
    paramByteBuffer.position(42);
    (0xFFFFFFFF & paramByteBuffer.getInt());
    byte[] arrayOfByte1 = new byte[n];
    paramByteBuffer.get(arrayOfByte1, 0, arrayOfByte1.length);
    String str1 = new String(arrayOfByte1, 0, arrayOfByte1.length, UTF_8);
    ZipEntry localZipEntry = new ZipEntry(str1);
    localZipEntry.setMethod(j);
    localZipEntry.setTime(getTime(k, m));
    localZipEntry.setCrc(l1);
    localZipEntry.setCompressedSize(l2);
    localZipEntry.setSize(l3);
    if (i2 > 0)
    {
      byte[] arrayOfByte3 = new byte[i2];
      paramByteBuffer.get(arrayOfByte3, 0, i2);
      String str2 = new String(arrayOfByte3, 0, arrayOfByte3.length, UTF_8);
      localZipEntry.setComment(str2);
    }
    if (i1 > 0)
    {
      byte[] arrayOfByte2 = new byte[i1];
      paramByteBuffer.get(arrayOfByte2, 0, i1);
      localZipEntry.setExtra(arrayOfByte2);
    }
    return localZipEntry;
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.multidex.ZipEntryReader
 * JD-Core Version:    0.7.0.1
 */