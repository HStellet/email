package com.google.appinventor.components.runtime;

import android.view.Menu;

public abstract interface OnCreateOptionsMenuListener
{
  public abstract void onCreateOptionsMenu(Menu paramMenu);
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.OnCreateOptionsMenuListener
 * JD-Core Version:    0.7.0.1
 */