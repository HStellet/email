package com.google.appinventor.components.runtime.util;

import android.content.Intent;
import android.provider.Telephony.Sms.Intents;
import android.telephony.SmsMessage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class KitkatUtil
{
  public static List<SmsMessage> getMessagesFromIntent(Intent paramIntent)
  {
    ArrayList localArrayList = new ArrayList();
    SmsMessage[] arrayOfSmsMessage = Telephony.Sms.Intents.getMessagesFromIntent(paramIntent);
    if ((arrayOfSmsMessage != null) && (arrayOfSmsMessage.length >= 0)) {
      Collections.addAll(localArrayList, arrayOfSmsMessage);
    }
    return localArrayList;
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.util.KitkatUtil
 * JD-Core Version:    0.7.0.1
 */