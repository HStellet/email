package com.google.appinventor.components.runtime.util;

import android.graphics.Point;
import android.view.Display;

public class JellybeanUtil
{
  public static void getRealSize(Display paramDisplay, Point paramPoint)
  {
    paramDisplay.getRealSize(paramPoint);
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.util.JellybeanUtil
 * JD-Core Version:    0.7.0.1
 */