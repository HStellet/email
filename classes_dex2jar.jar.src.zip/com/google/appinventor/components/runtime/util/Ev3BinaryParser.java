package com.google.appinventor.components.runtime.util;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Iterator;

public class Ev3BinaryParser
{
  private static byte PRIMPAR_1_BYTE = 1;
  private static byte PRIMPAR_2_BYTES = 2;
  private static byte PRIMPAR_4_BYTES = 3;
  private static byte PRIMPAR_ADDR;
  private static byte PRIMPAR_BYTES;
  private static byte PRIMPAR_CONST;
  private static byte PRIMPAR_CONST_SIGN;
  private static byte PRIMPAR_GLOBAL;
  private static byte PRIMPAR_HANDLE;
  private static byte PRIMPAR_INDEX;
  private static byte PRIMPAR_LOCAL;
  private static byte PRIMPAR_LONG;
  private static byte PRIMPAR_SHORT = 0;
  private static byte PRIMPAR_STRING = 4;
  private static byte PRIMPAR_STRING_OLD;
  private static byte PRIMPAR_VALUE;
  private static byte PRIMPAR_VARIABEL;
  
  static
  {
    PRIMPAR_LONG = -128;
    PRIMPAR_CONST = 0;
    PRIMPAR_VARIABEL = 64;
    PRIMPAR_LOCAL = 0;
    PRIMPAR_GLOBAL = 32;
    PRIMPAR_HANDLE = 16;
    PRIMPAR_ADDR = 8;
    PRIMPAR_INDEX = 31;
    PRIMPAR_CONST_SIGN = 32;
    PRIMPAR_VALUE = 63;
    PRIMPAR_BYTES = 7;
    PRIMPAR_STRING_OLD = 0;
  }
  
  public static byte[] encodeDirectCommand(byte paramByte, boolean paramBoolean, int paramInt1, int paramInt2, String paramString, Object... paramVarArgs)
  {
    if ((paramInt1 < 0) || (paramInt1 > 1023) || (paramInt2 < 0) || (paramInt2 > 63) || (paramString.length() != paramVarArgs.length)) {
      throw new IllegalArgumentException();
    }
    ArrayList localArrayList = new ArrayList();
    int i = 0;
    if (i < paramString.length())
    {
      int k = paramString.charAt(i);
      Object localObject = paramVarArgs[i];
      switch (k)
      {
      default: 
        throw new IllegalArgumentException("Illegal format string");
      case 99: 
        if ((localObject instanceof Byte)) {
          if ((((Byte)localObject).byteValue() <= 31) && (((Byte)localObject).byteValue() >= -31)) {
            localArrayList.add(encodeLC0(((Byte)localObject).byteValue()));
          }
        }
        break;
      }
      for (;;)
      {
        i++;
        break;
        localArrayList.add(encodeLC1(((Byte)localObject).byteValue()));
        continue;
        if ((localObject instanceof Short))
        {
          localArrayList.add(encodeLC2(((Short)localObject).shortValue()));
        }
        else if ((localObject instanceof Integer))
        {
          localArrayList.add(encodeLC4(((Integer)localObject).intValue()));
        }
        else
        {
          throw new IllegalArgumentException();
          if ((localObject instanceof Byte))
          {
            if ((((Byte)localObject).byteValue() <= 31) && (((Byte)localObject).byteValue() >= -31)) {
              localArrayList.add(encodeLV0(((Byte)localObject).byteValue()));
            } else {
              localArrayList.add(encodeLV1(((Byte)localObject).byteValue()));
            }
          }
          else if ((localObject instanceof Short))
          {
            localArrayList.add(encodeLV2(((Short)localObject).shortValue()));
          }
          else if ((localObject instanceof Integer))
          {
            localArrayList.add(encodeLV4(((Integer)localObject).intValue()));
          }
          else
          {
            throw new IllegalArgumentException();
            if ((localObject instanceof Byte))
            {
              if ((((Byte)localObject).byteValue() <= 31) && (((Byte)localObject).byteValue() >= -31)) {
                localArrayList.add(encodeGV0(((Byte)localObject).byteValue()));
              } else {
                localArrayList.add(encodeGV1(((Byte)localObject).byteValue()));
              }
            }
            else if ((localObject instanceof Short))
            {
              localArrayList.add(encodeGV2(((Short)localObject).shortValue()));
            }
            else if ((localObject instanceof Integer))
            {
              localArrayList.add(encodeGV4(((Integer)localObject).intValue()));
            }
            else
            {
              throw new IllegalArgumentException();
              if (!(localObject instanceof String)) {
                throw new IllegalArgumentException();
              }
              try
              {
                localArrayList.add(((String)localObject + '\000').getBytes("US-ASCII"));
              }
              catch (UnsupportedEncodingException localUnsupportedEncodingException)
              {
                throw new IllegalArgumentException();
              }
            }
          }
        }
      }
    }
    int j = 4;
    Iterator localIterator1 = localArrayList.iterator();
    while (localIterator1.hasNext()) {
      j += ((byte[])localIterator1.next()).length;
    }
    ByteBuffer localByteBuffer = ByteBuffer.allocate(j);
    localByteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    if (paramBoolean) {}
    for (byte b = 0;; b = -128)
    {
      localByteBuffer.put(b);
      byte[] arrayOfByte = new byte[2];
      arrayOfByte[0] = ((byte)(paramInt1 & 0xFF));
      arrayOfByte[1] = ((byte)(0x3 & paramInt1 >>> 8 | paramInt2 << 2));
      localByteBuffer.put(arrayOfByte);
      localByteBuffer.put(paramByte);
      Iterator localIterator2 = localArrayList.iterator();
      while (localIterator2.hasNext()) {
        localByteBuffer.put((byte[])localIterator2.next());
      }
    }
    return localByteBuffer.array();
  }
  
  public static byte[] encodeGV0(int paramInt)
  {
    byte[] arrayOfByte = new byte[1];
    arrayOfByte[0] = ((byte)(paramInt & PRIMPAR_INDEX | PRIMPAR_SHORT | PRIMPAR_VARIABEL | PRIMPAR_GLOBAL));
    return arrayOfByte;
  }
  
  public static byte[] encodeGV1(int paramInt)
  {
    byte[] arrayOfByte = new byte[2];
    arrayOfByte[0] = ((byte)(PRIMPAR_LONG | PRIMPAR_VARIABEL | PRIMPAR_GLOBAL | PRIMPAR_1_BYTE));
    arrayOfByte[1] = ((byte)(paramInt & 0xFF));
    return arrayOfByte;
  }
  
  public static byte[] encodeGV2(int paramInt)
  {
    byte[] arrayOfByte = new byte[3];
    arrayOfByte[0] = ((byte)(PRIMPAR_LONG | PRIMPAR_VARIABEL | PRIMPAR_GLOBAL | PRIMPAR_2_BYTES));
    arrayOfByte[1] = ((byte)(paramInt & 0xFF));
    arrayOfByte[2] = ((byte)(0xFF & paramInt >>> 8));
    return arrayOfByte;
  }
  
  public static byte[] encodeGV4(int paramInt)
  {
    byte[] arrayOfByte = new byte[5];
    arrayOfByte[0] = ((byte)(PRIMPAR_LONG | PRIMPAR_VARIABEL | PRIMPAR_GLOBAL | PRIMPAR_4_BYTES));
    arrayOfByte[1] = ((byte)(paramInt & 0xFF));
    arrayOfByte[2] = ((byte)(0xFF & paramInt >>> 8));
    arrayOfByte[3] = ((byte)(0xFF & paramInt >>> 16));
    arrayOfByte[4] = ((byte)(0xFF & paramInt >>> 24));
    return arrayOfByte;
  }
  
  public static byte[] encodeLC0(byte paramByte)
  {
    if ((paramByte < -31) || (paramByte > 31)) {
      throw new IllegalArgumentException("Encoded value must be in range [0, 127]");
    }
    byte[] arrayOfByte = new byte[1];
    arrayOfByte[0] = ((byte)(paramByte & PRIMPAR_VALUE));
    return arrayOfByte;
  }
  
  public static byte[] encodeLC1(byte paramByte)
  {
    byte[] arrayOfByte = new byte[2];
    arrayOfByte[0] = ((byte)((byte)(PRIMPAR_LONG | PRIMPAR_CONST) | PRIMPAR_1_BYTE));
    arrayOfByte[1] = ((byte)(paramByte & 0xFF));
    return arrayOfByte;
  }
  
  public static byte[] encodeLC2(short paramShort)
  {
    byte[] arrayOfByte = new byte[3];
    arrayOfByte[0] = ((byte)((byte)(PRIMPAR_LONG | PRIMPAR_CONST) | PRIMPAR_2_BYTES));
    arrayOfByte[1] = ((byte)(paramShort & 0xFF));
    arrayOfByte[2] = ((byte)(0xFF & paramShort >>> 8));
    return arrayOfByte;
  }
  
  public static byte[] encodeLC4(int paramInt)
  {
    byte[] arrayOfByte = new byte[5];
    arrayOfByte[0] = ((byte)((byte)(PRIMPAR_LONG | PRIMPAR_CONST) | PRIMPAR_4_BYTES));
    arrayOfByte[1] = ((byte)(paramInt & 0xFF));
    arrayOfByte[2] = ((byte)(0xFF & paramInt >>> 8));
    arrayOfByte[3] = ((byte)(0xFF & paramInt >>> 16));
    arrayOfByte[4] = ((byte)(0xFF & paramInt >>> 24));
    return arrayOfByte;
  }
  
  public static byte[] encodeLV0(int paramInt)
  {
    byte[] arrayOfByte = new byte[1];
    arrayOfByte[0] = ((byte)(paramInt & PRIMPAR_INDEX | PRIMPAR_SHORT | PRIMPAR_VARIABEL | PRIMPAR_LOCAL));
    return arrayOfByte;
  }
  
  public static byte[] encodeLV1(int paramInt)
  {
    byte[] arrayOfByte = new byte[2];
    arrayOfByte[0] = ((byte)(PRIMPAR_LONG | PRIMPAR_VARIABEL | PRIMPAR_LOCAL | PRIMPAR_1_BYTE));
    arrayOfByte[1] = ((byte)(paramInt & 0xFF));
    return arrayOfByte;
  }
  
  public static byte[] encodeLV2(int paramInt)
  {
    byte[] arrayOfByte = new byte[3];
    arrayOfByte[0] = ((byte)(PRIMPAR_LONG | PRIMPAR_VARIABEL | PRIMPAR_LOCAL | PRIMPAR_2_BYTES));
    arrayOfByte[1] = ((byte)(paramInt & 0xFF));
    arrayOfByte[2] = ((byte)(0xFF & paramInt >>> 8));
    return arrayOfByte;
  }
  
  public static byte[] encodeLV4(int paramInt)
  {
    byte[] arrayOfByte = new byte[5];
    arrayOfByte[0] = ((byte)(PRIMPAR_LONG | PRIMPAR_VARIABEL | PRIMPAR_LOCAL | PRIMPAR_4_BYTES));
    arrayOfByte[1] = ((byte)(paramInt & 0xFF));
    arrayOfByte[2] = ((byte)(0xFF & paramInt >>> 8));
    arrayOfByte[3] = ((byte)(0xFF & paramInt >>> 16));
    arrayOfByte[4] = ((byte)(0xFF & paramInt >>> 24));
    return arrayOfByte;
  }
  
  public static byte[] encodeSystemCommand(byte paramByte, boolean paramBoolean, Object... paramVarArgs)
  {
    int i = 2;
    int j = paramVarArgs.length;
    int k = 0;
    if (k < j)
    {
      Object localObject2 = paramVarArgs[k];
      if ((localObject2 instanceof Byte)) {
        i++;
      }
      for (;;)
      {
        k++;
        break;
        if ((localObject2 instanceof Short))
        {
          i += 2;
        }
        else if ((localObject2 instanceof Integer))
        {
          i += 4;
        }
        else
        {
          if (!(localObject2 instanceof String)) {
            break label91;
          }
          i += 1 + ((String)localObject2).length();
        }
      }
      label91:
      throw new IllegalArgumentException("Parameters should be one of the class types: Byte, Short, Integer, String");
    }
    ByteBuffer localByteBuffer = ByteBuffer.allocate(i);
    localByteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    byte b;
    int n;
    label145:
    Object localObject1;
    if (paramBoolean)
    {
      b = 1;
      localByteBuffer.put(b);
      localByteBuffer.put(paramByte);
      int m = paramVarArgs.length;
      n = 0;
      if (n >= m) {
        break label299;
      }
      localObject1 = paramVarArgs[n];
      if (!(localObject1 instanceof Byte)) {
        break label193;
      }
      localByteBuffer.put(((Byte)localObject1).byteValue());
    }
    for (;;)
    {
      n++;
      break label145;
      b = -127;
      break;
      label193:
      if ((localObject1 instanceof Short)) {
        localByteBuffer.putShort(((Short)localObject1).shortValue());
      } else if ((localObject1 instanceof Integer)) {
        localByteBuffer.putInt(((Integer)localObject1).intValue());
      } else if ((localObject1 instanceof String)) {
        try
        {
          localByteBuffer.put(((String)localObject1).getBytes("US-ASCII"));
          localByteBuffer.put((byte)0);
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException)
        {
          throw new IllegalArgumentException("Non-ASCII string encoding is not supported");
        }
      }
    }
    throw new IllegalArgumentException("Parameters should be one of the class types: Byte, Short, Integer, String");
    label299:
    return localByteBuffer.array();
  }
  
  public static byte[] pack(String paramString, Object... paramVarArgs)
    throws IllegalArgumentException
  {
    String[] arrayOfString = paramString.split("(?<=\\D)");
    FormatLiteral[] arrayOfFormatLiteral = new FormatLiteral[arrayOfString.length];
    int i = 0;
    int j = 0;
    int k = 0;
    if (k < arrayOfString.length)
    {
      String str = arrayOfString[k];
      char c = str.charAt(-1 + str.length());
      int i12 = 1;
      int i13 = str.length();
      int i14 = 0;
      if (i13 != 1)
      {
        i12 = Integer.parseInt(str.substring(0, -1 + str.length()));
        i14 = 1;
        if (i12 < 1) {
          throw new IllegalArgumentException("Illegal format string");
        }
      }
      switch (c)
      {
      default: 
        throw new IllegalArgumentException("Illegal format string");
      case 'x': 
        j += i12;
      }
      for (;;)
      {
        FormatLiteral localFormatLiteral2 = new FormatLiteral(c, i12);
        arrayOfFormatLiteral[k] = localFormatLiteral2;
        k++;
        break;
        j += i12;
        i += i12;
        continue;
        j += i12;
        i++;
        continue;
        j += i12 * 2;
        i += i12;
        continue;
        j += i12 * 2;
        i++;
        continue;
        j += i12 * 4;
        i += i12;
        continue;
        j += i12 * 4;
        i++;
        continue;
        j += i12 * 8;
        i += i12;
        continue;
        j += i12 * 8;
        i++;
        continue;
        j += i12 * 4;
        i += i12;
        continue;
        j += i12 * 4;
        i++;
        continue;
        if (i12 != ((String)paramVarArgs[i]).length()) {
          throw new IllegalArgumentException("Illegal format string");
        }
        j += i12;
        i++;
        continue;
        if (i14 != 0) {
          throw new IllegalArgumentException("Illegal format string");
        }
        j += 1 + ((String)paramVarArgs[i]).length();
        i++;
      }
    }
    if (i != paramVarArgs.length) {
      throw new IllegalArgumentException("Illegal format string");
    }
    int m = 0;
    ByteBuffer localByteBuffer = ByteBuffer.allocate(j);
    localByteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    int n = arrayOfFormatLiteral.length;
    int i1 = 0;
    if (i1 < n)
    {
      FormatLiteral localFormatLiteral1 = arrayOfFormatLiteral[i1];
      switch (localFormatLiteral1.symbol)
      {
      }
      for (;;)
      {
        i1++;
        break;
        for (int i11 = 0; i11 < localFormatLiteral1.size; i11++) {
          localByteBuffer.put((byte)0);
        }
        continue;
        for (int i10 = 0; i10 < localFormatLiteral1.size; i10++)
        {
          localByteBuffer.put(((Byte)paramVarArgs[m]).byteValue());
          m++;
        }
        continue;
        localByteBuffer.put((byte[])paramVarArgs[m]);
        m++;
        continue;
        for (int i9 = 0; i9 < localFormatLiteral1.size; i9++)
        {
          localByteBuffer.putShort(((Short)paramVarArgs[m]).shortValue());
          m++;
        }
        continue;
        for (int i8 = 0; i8 < localFormatLiteral1.size; i8++) {
          localByteBuffer.putShort(((short[])(short[])paramVarArgs[m])[i8]);
        }
        m++;
        continue;
        for (int i7 = 0; i7 < localFormatLiteral1.size; i7++)
        {
          localByteBuffer.putInt(((Integer)paramVarArgs[m]).intValue());
          m++;
        }
        continue;
        for (int i6 = 0; i6 < localFormatLiteral1.size; i6++) {
          localByteBuffer.putInt(((int[])(int[])paramVarArgs[m])[i6]);
        }
        m++;
        continue;
        for (int i5 = 0; i5 < localFormatLiteral1.size; i5++)
        {
          localByteBuffer.putLong(((Long)paramVarArgs[m]).longValue());
          m++;
        }
        continue;
        for (int i4 = 0; i4 < localFormatLiteral1.size; i4++) {
          localByteBuffer.putLong(((long[])(long[])paramVarArgs[m])[i4]);
        }
        m++;
        continue;
        for (int i3 = 0; i3 < localFormatLiteral1.size; i3++)
        {
          localByteBuffer.putFloat(((Float)paramVarArgs[m]).floatValue());
          m++;
        }
        continue;
        for (int i2 = 0; i2 < localFormatLiteral1.size; i2++) {
          localByteBuffer.putFloat(((float[])(float[])paramVarArgs[m])[i2]);
        }
        m++;
        continue;
        try
        {
          localByteBuffer.put(((String)paramVarArgs[m]).getBytes("US-ASCII"));
          m++;
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException2)
        {
          throw new IllegalArgumentException();
        }
        try
        {
          localByteBuffer.put(((String)paramVarArgs[m]).getBytes("US-ASCII"));
          localByteBuffer.put((byte)0);
          m++;
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException1)
        {
          throw new IllegalArgumentException();
        }
      }
    }
    return localByteBuffer.array();
  }
  
  public static Object[] unpack(String paramString, byte[] paramArrayOfByte)
    throws IllegalArgumentException
  {
    String[] arrayOfString = paramString.split("(?<=\\D)");
    ArrayList localArrayList = new ArrayList();
    ByteBuffer localByteBuffer = ByteBuffer.wrap(paramArrayOfByte);
    localByteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    int i = arrayOfString.length;
    int j = 0;
    if (j < i)
    {
      String str1 = arrayOfString[j];
      int k = 1;
      int m = str1.charAt(-1 + str1.length());
      int n = str1.length();
      int i1 = 0;
      if (n > 1)
      {
        i1 = 1;
        k = Integer.parseInt(str1.substring(0, -1 + str1.length()));
        if (k < 1) {
          throw new IllegalArgumentException("Illegal format string");
        }
      }
      switch (m)
      {
      }
      do
      {
        throw new IllegalArgumentException("Illegal format string");
        int i12 = 0;
        while (i12 < k)
        {
          localByteBuffer.get();
          i12++;
          continue;
          int i11 = 0;
          while (i11 < k)
          {
            localArrayList.add(Byte.valueOf(localByteBuffer.get()));
            i11++;
            continue;
            byte[] arrayOfByte2 = new byte[k];
            localByteBuffer.get(arrayOfByte2, 0, k);
            localArrayList.add(arrayOfByte2);
          }
        }
        for (;;)
        {
          j++;
          break;
          for (int i10 = 0; i10 < k; i10++) {
            localArrayList.add(Short.valueOf(localByteBuffer.getShort()));
          }
          continue;
          short[] arrayOfShort = new short[k];
          for (int i9 = 0; i9 < k; i9 = (short)(i9 + 1)) {
            arrayOfShort[i9] = localByteBuffer.getShort();
          }
          localArrayList.add(arrayOfShort);
          continue;
          for (int i8 = 0; i8 < k; i8++) {
            localArrayList.add(Integer.valueOf(localByteBuffer.getInt()));
          }
          continue;
          int[] arrayOfInt = new int[k];
          for (int i7 = 0; i7 < k; i7++) {
            arrayOfInt[i7] = localByteBuffer.getInt();
          }
          localArrayList.add(arrayOfInt);
          continue;
          for (int i6 = 0; i6 < k; i6++) {
            localArrayList.add(Long.valueOf(localByteBuffer.getLong()));
          }
          continue;
          long[] arrayOfLong = new long[k];
          for (int i5 = 0; i5 < k; i5++) {
            arrayOfLong[i5] = localByteBuffer.getLong();
          }
          localArrayList.add(arrayOfLong);
          continue;
          for (int i4 = 0; i4 < k; i4++) {
            localArrayList.add(Float.valueOf(localByteBuffer.getFloat()));
          }
          continue;
          float[] arrayOfFloat = new float[k];
          for (int i3 = 0; i3 < k; i3++) {
            arrayOfFloat[i3] = localByteBuffer.getFloat();
          }
          localArrayList.add(arrayOfFloat);
          continue;
          byte[] arrayOfByte1 = new byte[k];
          localByteBuffer.get(arrayOfByte1, 0, k);
          try
          {
            String str2 = new String(arrayOfByte1, "US-ASCII");
            localArrayList.add(str2);
          }
          catch (UnsupportedEncodingException localUnsupportedEncodingException)
          {
            throw new IllegalArgumentException();
          }
          if (i1 != 0) {
            throw new IllegalArgumentException("Illegal format string");
          }
          StringBuffer localStringBuffer = new StringBuffer();
          for (;;)
          {
            int i2 = localByteBuffer.get();
            if (i2 == 0) {
              break;
            }
            localStringBuffer.append((char)i2);
          }
          localArrayList.add(localStringBuffer.toString());
        }
        if (i1 != 0) {
          throw new IllegalArgumentException("Illegal format string");
        }
      } while (!localByteBuffer.hasRemaining());
      throw new IllegalArgumentException("Illegal format string");
    }
    return localArrayList.toArray();
  }
  
  private static class FormatLiteral
  {
    public int size;
    public char symbol;
    
    public FormatLiteral(char paramChar, int paramInt)
    {
      this.symbol = paramChar;
      this.size = paramInt;
    }
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.util.Ev3BinaryParser
 * JD-Core Version:    0.7.0.1
 */