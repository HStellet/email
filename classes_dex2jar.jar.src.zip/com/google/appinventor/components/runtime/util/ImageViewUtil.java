package com.google.appinventor.components.runtime.util;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.support.v7.internal.widget.TintImageView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import java.util.LinkedList;
import java.util.Queue;

public final class ImageViewUtil
{
  private static final boolean canUpdate;
  
  static
  {
    try
    {
      TintImageView.class.getMethod("setImageTintMode", new Class[] { PorterDuff.Mode.class });
      bool = true;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      for (;;)
      {
        boolean bool = false;
      }
    }
    canUpdate = bool;
  }
  
  private static TintImageView findOverflowMenuView(Activity paramActivity)
  {
    ViewGroup localViewGroup1 = (ViewGroup)paramActivity.getWindow().getDecorView();
    LinkedList localLinkedList = new LinkedList();
    localLinkedList.add(localViewGroup1);
    while (localLinkedList.size() > 0)
    {
      ViewGroup localViewGroup2 = (ViewGroup)localLinkedList.poll();
      for (int i = 0; i < localViewGroup2.getChildCount(); i++)
      {
        View localView = localViewGroup2.getChildAt(i);
        if ((localView instanceof TintImageView)) {
          return (TintImageView)localView;
        }
        if ((localView instanceof ViewGroup)) {
          localLinkedList.add((ViewGroup)localView);
        }
      }
    }
    return null;
  }
  
  public static void setMenuButtonColor(Activity paramActivity, int paramInt)
  {
    TintImageView localTintImageView;
    ColorStateList localColorStateList;
    if (canUpdate)
    {
      localTintImageView = findOverflowMenuView(paramActivity);
      if (localTintImageView != null) {
        localColorStateList = new ColorStateList(new int[][] { new int[0] }, new int[] { paramInt });
      }
    }
    try
    {
      localTintImageView.setImageTintMode(PorterDuff.Mode.MULTIPLY);
      localTintImageView.setImageTintList(localColorStateList);
      return;
    }
    catch (NoSuchMethodError localNoSuchMethodError) {}
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.util.ImageViewUtil
 * JD-Core Version:    0.7.0.1
 */