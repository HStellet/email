package com.google.appinventor.components.runtime.util;

public abstract interface AsyncCallbackPair<T>
{
  public abstract void onFailure(String paramString);
  
  public abstract void onSuccess(T paramT);
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.util.AsyncCallbackPair
 * JD-Core Version:    0.7.0.1
 */