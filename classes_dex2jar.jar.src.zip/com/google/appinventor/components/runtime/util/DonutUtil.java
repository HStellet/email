package com.google.appinventor.components.runtime.util;

import android.graphics.Bitmap;
import android.view.View;

public class DonutUtil
{
  public static void buildDrawingCache(View paramView, boolean paramBoolean)
  {
    paramView.buildDrawingCache(paramBoolean);
  }
  
  public static Bitmap getDrawingCache(View paramView, boolean paramBoolean)
  {
    return paramView.getDrawingCache(paramBoolean);
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.util.DonutUtil
 * JD-Core Version:    0.7.0.1
 */