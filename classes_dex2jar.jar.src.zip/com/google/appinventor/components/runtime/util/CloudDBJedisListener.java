package com.google.appinventor.components.runtime.util;

import android.util.Log;
import com.google.appinventor.components.runtime.CloudDB;
import java.util.Iterator;
import java.util.List;
import org.json.JSONException;
import redis.clients.jedis.JedisPubSub;

public class CloudDBJedisListener
  extends JedisPubSub
{
  private static final boolean DEBUG;
  private static String LOG_TAG = "CloudDB";
  public CloudDB cloudDB;
  private Thread myThread;
  
  public CloudDBJedisListener(CloudDB paramCloudDB)
  {
    this.cloudDB = paramCloudDB;
    this.myThread = Thread.currentThread();
  }
  
  public void onMessage(String paramString1, String paramString2)
  {
    try
    {
      List localList = (List)JsonUtil.getObjectFromJson(paramString2);
      String str = (String)localList.get(0);
      Iterator localIterator = ((List)localList.get(1)).iterator();
      while (localIterator.hasNext())
      {
        Object localObject = localIterator.next();
        this.cloudDB.DataChanged(str, localObject);
      }
      return;
    }
    catch (JSONException localJSONException)
    {
      Log.e(LOG_TAG, "onMessage: JSONException", localJSONException);
      this.cloudDB.CloudDBError("System Error: " + localJSONException.getMessage());
    }
  }
  
  public void onSubscribe(String paramString, int paramInt) {}
  
  public void terminate()
  {
    this.myThread.interrupt();
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.util.CloudDBJedisListener
 * JD-Core Version:    0.7.0.1
 */