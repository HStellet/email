package com.google.appinventor.components.runtime.util;

import java.util.Iterator;
import java.util.List;

public final class JavaJoinListOfStrings
{
  private static final boolean DEBUG = false;
  public static final String LOG_TAG = "JavaJoinListOfStrings";
  
  private static String join(List<Object> paramList, String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    int i = 1;
    Iterator localIterator = paramList.iterator();
    if (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if (i != 0) {
        i = 0;
      }
      for (;;)
      {
        localStringBuilder.append(localObject.toString());
        break;
        localStringBuilder.append(paramString);
      }
    }
    return localStringBuilder.toString();
  }
  
  public static String joinStrings(List<Object> paramList, String paramString)
  {
    return join(paramList, paramString);
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.util.JavaJoinListOfStrings
 * JD-Core Version:    0.7.0.1
 */