package com.google.appinventor.components.runtime.util;

import android.os.Build.VERSION;
import android.widget.TextView;

public final class IceCreamSandwichUtil
{
  public static void setAllCaps(TextView paramTextView, boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 14) {
      paramTextView.setAllCaps(paramBoolean);
    }
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.util.IceCreamSandwichUtil
 * JD-Core Version:    0.7.0.1
 */