package com.google.appinventor.components.runtime.util;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Spinner;

public class HoneycombUtil
{
  public static final int VIEWGROUP_MEASURED_HEIGHT_STATE_SHIFT = 16;
  
  public static int combineMeasuredStates(ViewGroup paramViewGroup, int paramInt1, int paramInt2)
  {
    return ViewGroup.combineMeasuredStates(paramInt1, paramInt2);
  }
  
  public static int getMeasuredState(View paramView)
  {
    return paramView.getMeasuredState();
  }
  
  public static Spinner makeSpinner(Context paramContext)
  {
    return new Spinner(paramContext, 0);
  }
  
  public static int resolveSizeAndState(ViewGroup paramViewGroup, int paramInt1, int paramInt2, int paramInt3)
  {
    return ViewGroup.resolveSizeAndState(paramInt1, paramInt2, paramInt3);
  }
  
  public static void viewSetRotate(View paramView, double paramDouble)
  {
    paramView.setRotation((float)paramDouble);
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.util.HoneycombUtil
 * JD-Core Version:    0.7.0.1
 */