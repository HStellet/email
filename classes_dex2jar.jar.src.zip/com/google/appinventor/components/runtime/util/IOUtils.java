package com.google.appinventor.components.runtime.util;

import android.util.Log;
import java.io.Closeable;
import java.io.IOException;

public final class IOUtils
{
  public static void closeQuietly(String paramString, Closeable paramCloseable)
  {
    if (paramCloseable != null) {}
    try
    {
      paramCloseable.close();
      return;
    }
    catch (IOException localIOException)
    {
      Log.w(paramString, "Failed to close resource", localIOException);
    }
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.util.IOUtils
 * JD-Core Version:    0.7.0.1
 */