package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.runtime.errors.DispatchableError;
import com.google.appinventor.components.runtime.errors.IterationError;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.LineString;
import org.locationtech.jts.geom.LinearRing;
import org.locationtech.jts.geom.Point;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.geom.PrecisionModel;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.util.GeoPoint;

public final class GeometryUtil
{
  public static final double EARTH_RADIUS = 6378137.0D;
  private static final GeometryFactory FACTORY = new GeometryFactory(new PrecisionModel(), 4326);
  public static final double ONE_DEG_IN_METERS = 111319.49079327358D;
  public static final int WEB_MERCATOR_SRID = 4326;
  
  public static YailList asYailList(IGeoPoint paramIGeoPoint)
  {
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = Double.valueOf(paramIGeoPoint.getLatitude());
    arrayOfObject[1] = Double.valueOf(paramIGeoPoint.getLongitude());
    return YailList.makeList(arrayOfObject);
  }
  
  public static double bearingTo(MapFactory.MapMarker paramMapMarker1, MapFactory.MapMarker paramMapMarker2)
  {
    return paramMapMarker1.getCentroid().bearingTo(paramMapMarker2.getCentroid());
  }
  
  public static double bearingToCentroid(MapFactory.MapMarker paramMapMarker, MapFactory.MapCircle paramMapCircle)
  {
    return paramMapMarker.getCentroid().bearingTo(paramMapCircle.getCentroid());
  }
  
  public static double bearingToCentroid(MapFactory.MapMarker paramMapMarker, MapFactory.MapLineString paramMapLineString)
  {
    return paramMapMarker.getCentroid().bearingTo(paramMapLineString.getCentroid());
  }
  
  public static double bearingToCentroid(MapFactory.MapMarker paramMapMarker, MapFactory.MapPolygon paramMapPolygon)
  {
    return paramMapMarker.getCentroid().bearingTo(paramMapPolygon.getCentroid());
  }
  
  public static double bearingToCentroid(MapFactory.MapMarker paramMapMarker, MapFactory.MapRectangle paramMapRectangle)
  {
    return paramMapMarker.getCentroid().bearingTo(paramMapRectangle.getCentroid());
  }
  
  public static double bearingToEdge(MapFactory.MapMarker paramMapMarker, MapFactory.MapCircle paramMapCircle)
  {
    return paramMapMarker.getCentroid().bearingTo(paramMapCircle.getCentroid());
  }
  
  public static double bearingToEdge(MapFactory.MapMarker paramMapMarker, MapFactory.MapLineString paramMapLineString)
  {
    return paramMapMarker.getCentroid().bearingTo(paramMapLineString.getCentroid());
  }
  
  public static double bearingToEdge(MapFactory.MapMarker paramMapMarker, MapFactory.MapPolygon paramMapPolygon)
  {
    return paramMapMarker.getCentroid().bearingTo(paramMapPolygon.getCentroid());
  }
  
  public static double bearingToEdge(MapFactory.MapMarker paramMapMarker, MapFactory.MapRectangle paramMapRectangle)
  {
    return paramMapMarker.getCentroid().bearingTo(paramMapRectangle.getCentroid());
  }
  
  public static double coerceToDouble(Object paramObject)
  {
    if ((paramObject instanceof Number)) {
      return ((Number)paramObject).doubleValue();
    }
    try
    {
      double d = Double.parseDouble(paramObject.toString());
      return d;
    }
    catch (NumberFormatException localNumberFormatException) {}
    return (0.0D / 0.0D);
  }
  
  public static GeoPoint coerceToPoint(Object paramObject1, Object paramObject2)
  {
    double d1 = coerceToDouble(paramObject1);
    double d2 = coerceToDouble(paramObject2);
    if (Double.isNaN(d1)) {
      throw new IllegalArgumentException("Latitude must be a numeric.");
    }
    if (Double.isNaN(d2)) {
      throw new IllegalArgumentException("Longitude must be a numeric.");
    }
    if ((d1 < -90.0D) || (d1 > 90.0D)) {
      throw new IllegalArgumentException("Latitude must be between -90 and 90.");
    }
    if ((d2 < -180.0D) || (d2 > 180.0D)) {
      throw new IllegalArgumentException("Longitude must be between -180 and 180.");
    }
    return new GeoPoint(d1, d2);
  }
  
  public static Geometry createGeometry(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    GeometryFactory localGeometryFactory = FACTORY;
    Coordinate[] arrayOfCoordinate = new Coordinate[5];
    arrayOfCoordinate[0] = new Coordinate(paramDouble2, paramDouble1);
    arrayOfCoordinate[1] = new Coordinate(paramDouble2, paramDouble3);
    arrayOfCoordinate[2] = new Coordinate(paramDouble4, paramDouble3);
    arrayOfCoordinate[3] = new Coordinate(paramDouble4, paramDouble1);
    arrayOfCoordinate[4] = new Coordinate(paramDouble2, paramDouble1);
    return localGeometryFactory.createPolygon(arrayOfCoordinate);
  }
  
  public static Geometry createGeometry(List<GeoPoint> paramList)
  {
    return FACTORY.createLineString(pointsToCoordinates(paramList));
  }
  
  public static Geometry createGeometry(List<List<GeoPoint>> paramList, List<List<List<GeoPoint>>> paramList1)
  {
    if (paramList == null) {
      throw new IllegalArgumentException("points must not be null.");
    }
    if ((paramList1 != null) && (!paramList1.isEmpty()) && (paramList1.size() != paramList.size())) {
      throw new IllegalArgumentException("holes must either be null or the same length as points.");
    }
    Polygon[] arrayOfPolygon = new Polygon[paramList.size()];
    int i = 0;
    Iterator localIterator1;
    if ((paramList1 == null) || (paramList1.isEmpty())) {
      localIterator1 = paramList.iterator();
    }
    while (localIterator1.hasNext())
    {
      List localList = (List)localIterator1.next();
      int j = i + 1;
      arrayOfPolygon[i] = ringToPolygon(localList);
      i = j;
      continue;
      Iterator localIterator2 = paramList.iterator();
      Iterator localIterator3 = paramList1.iterator();
      while (localIterator2.hasNext())
      {
        int k = i + 1;
        arrayOfPolygon[i] = ringToPolygon((List)localIterator2.next(), (List)localIterator3.next());
        i = k;
      }
    }
    if (arrayOfPolygon.length == 1) {
      return arrayOfPolygon[0];
    }
    return FACTORY.createMultiPolygon(arrayOfPolygon);
  }
  
  public static Geometry createGeometry(GeoPoint paramGeoPoint)
  {
    return FACTORY.createPoint(geoPointToCoordinate(paramGeoPoint));
  }
  
  public static double distanceBetween(MapFactory.MapMarker paramMapMarker1, MapFactory.MapMarker paramMapMarker2)
  {
    return distanceBetween(paramMapMarker1.getLocation(), paramMapMarker2.getLocation());
  }
  
  public static double distanceBetween(MapFactory.MapMarker paramMapMarker, GeoPoint paramGeoPoint)
  {
    return distanceBetween(paramMapMarker.getLocation(), paramGeoPoint);
  }
  
  public static double distanceBetween(IGeoPoint paramIGeoPoint1, IGeoPoint paramIGeoPoint2)
  {
    double d1 = Math.toRadians(paramIGeoPoint1.getLatitude());
    double d2 = Math.toRadians(paramIGeoPoint1.getLongitude());
    double d3 = Math.toRadians(paramIGeoPoint2.getLatitude());
    double d4 = Math.toRadians(paramIGeoPoint2.getLongitude());
    double d5 = d3 - d1;
    double d6 = d4 - d2;
    double d7 = Math.pow(Math.sin(d5 / 2.0D), 2.0D) + Math.cos(d1) * Math.cos(d3) * Math.pow(Math.sin(d6 / 2.0D), 2.0D);
    return 6378137.0D * (2.0D * Math.atan2(Math.sqrt(d7), Math.sqrt(1.0D - d7)));
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapCircle paramMapCircle1, MapFactory.MapCircle paramMapCircle2)
  {
    return distanceBetween(paramMapCircle1.getCentroid(), paramMapCircle2.getCentroid());
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapCircle paramMapCircle, MapFactory.MapRectangle paramMapRectangle)
  {
    return distanceBetween(paramMapCircle.getCentroid(), paramMapRectangle.getCentroid());
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapCircle paramMapCircle, GeoPoint paramGeoPoint)
  {
    return distanceBetween(paramMapCircle.getCentroid(), paramGeoPoint);
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapLineString paramMapLineString, MapFactory.MapCircle paramMapCircle)
  {
    return distanceBetween(paramMapLineString.getCentroid(), paramMapCircle.getCentroid());
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapLineString paramMapLineString1, MapFactory.MapLineString paramMapLineString2)
  {
    return distanceBetween(paramMapLineString1.getCentroid(), paramMapLineString2.getCentroid());
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapLineString paramMapLineString, MapFactory.MapPolygon paramMapPolygon)
  {
    return distanceBetween(paramMapLineString.getCentroid(), paramMapPolygon.getCentroid());
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapLineString paramMapLineString, MapFactory.MapRectangle paramMapRectangle)
  {
    return distanceBetween(paramMapLineString.getCentroid(), paramMapRectangle.getCentroid());
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapLineString paramMapLineString, GeoPoint paramGeoPoint)
  {
    return distanceBetween(paramMapLineString.getCentroid(), paramGeoPoint);
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapMarker paramMapMarker, MapFactory.MapCircle paramMapCircle)
  {
    return distanceBetween(paramMapMarker.getCentroid(), paramMapCircle.getCentroid());
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapMarker paramMapMarker, MapFactory.MapLineString paramMapLineString)
  {
    return distanceBetween(paramMapMarker.getCentroid(), paramMapLineString.getCentroid());
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapMarker paramMapMarker, MapFactory.MapPolygon paramMapPolygon)
  {
    return distanceBetween(paramMapMarker.getCentroid(), paramMapPolygon.getCentroid());
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapMarker paramMapMarker, MapFactory.MapRectangle paramMapRectangle)
  {
    return distanceBetween(paramMapMarker.getCentroid(), paramMapRectangle.getCentroid());
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapPolygon paramMapPolygon, MapFactory.MapCircle paramMapCircle)
  {
    return distanceBetween(paramMapPolygon.getCentroid(), paramMapCircle.getCentroid());
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapPolygon paramMapPolygon1, MapFactory.MapPolygon paramMapPolygon2)
  {
    return distanceBetween(paramMapPolygon1.getCentroid(), paramMapPolygon2.getCentroid());
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapPolygon paramMapPolygon, MapFactory.MapRectangle paramMapRectangle)
  {
    return distanceBetween(paramMapPolygon.getCentroid(), paramMapRectangle.getCentroid());
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapPolygon paramMapPolygon, GeoPoint paramGeoPoint)
  {
    return distanceBetween(paramMapPolygon.getCentroid(), paramGeoPoint);
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapRectangle paramMapRectangle1, MapFactory.MapRectangle paramMapRectangle2)
  {
    return distanceBetween(paramMapRectangle1.getCentroid(), paramMapRectangle2.getCentroid());
  }
  
  public static double distanceBetweenCentroids(MapFactory.MapRectangle paramMapRectangle, GeoPoint paramGeoPoint)
  {
    return distanceBetween(paramMapRectangle.getCentroid(), paramGeoPoint);
  }
  
  public static double distanceBetweenEdges(MapFactory.MapCircle paramMapCircle1, MapFactory.MapCircle paramMapCircle2)
  {
    double d = distanceBetween(paramMapCircle1.getCentroid(), paramMapCircle2.getCentroid()) - paramMapCircle1.Radius() - paramMapCircle2.Radius();
    if (d < 0.0D) {
      d = 0.0D;
    }
    return d;
  }
  
  public static double distanceBetweenEdges(MapFactory.MapCircle paramMapCircle, MapFactory.MapRectangle paramMapRectangle)
  {
    double d = 111319.49079327358D * paramMapRectangle.getGeometry().distance(createGeometry(paramMapCircle.getCentroid())) - paramMapCircle.Radius();
    if (d < 0.0D) {
      d = 0.0D;
    }
    return d;
  }
  
  public static double distanceBetweenEdges(MapFactory.MapCircle paramMapCircle, GeoPoint paramGeoPoint)
  {
    double d = distanceBetween(paramMapCircle.getCentroid(), paramGeoPoint) - paramMapCircle.Radius();
    if (d < 0.0D) {
      d = 0.0D;
    }
    return d;
  }
  
  public static double distanceBetweenEdges(MapFactory.MapLineString paramMapLineString, MapFactory.MapCircle paramMapCircle)
  {
    double d = 111319.49079327358D * paramMapLineString.getGeometry().distance(createGeometry(paramMapCircle.getCentroid())) - paramMapCircle.Radius();
    if (d < 0.0D) {
      d = 0.0D;
    }
    return d;
  }
  
  public static double distanceBetweenEdges(MapFactory.MapLineString paramMapLineString1, MapFactory.MapLineString paramMapLineString2)
  {
    return 111319.49079327358D * paramMapLineString1.getGeometry().distance(paramMapLineString2.getGeometry());
  }
  
  public static double distanceBetweenEdges(MapFactory.MapLineString paramMapLineString, MapFactory.MapPolygon paramMapPolygon)
  {
    return 111319.49079327358D * paramMapLineString.getGeometry().distance(paramMapPolygon.getGeometry());
  }
  
  public static double distanceBetweenEdges(MapFactory.MapLineString paramMapLineString, MapFactory.MapRectangle paramMapRectangle)
  {
    return 111319.49079327358D * paramMapLineString.getGeometry().distance(paramMapRectangle.getGeometry());
  }
  
  public static double distanceBetweenEdges(MapFactory.MapLineString paramMapLineString, GeoPoint paramGeoPoint)
  {
    return 111319.49079327358D * paramMapLineString.getGeometry().distance(createGeometry(paramGeoPoint));
  }
  
  public static double distanceBetweenEdges(MapFactory.MapMarker paramMapMarker, MapFactory.MapCircle paramMapCircle)
  {
    double d = paramMapMarker.getCentroid().distanceTo(paramMapCircle.getCentroid()) - paramMapCircle.Radius();
    if (d < 0.0D) {
      d = 0.0D;
    }
    return d;
  }
  
  public static double distanceBetweenEdges(MapFactory.MapMarker paramMapMarker, MapFactory.MapLineString paramMapLineString)
  {
    return 111319.49079327358D * paramMapMarker.getGeometry().distance(paramMapLineString.getGeometry());
  }
  
  public static double distanceBetweenEdges(MapFactory.MapMarker paramMapMarker, MapFactory.MapPolygon paramMapPolygon)
  {
    return 111319.49079327358D * paramMapMarker.getGeometry().distance(paramMapPolygon.getGeometry());
  }
  
  public static double distanceBetweenEdges(MapFactory.MapMarker paramMapMarker, MapFactory.MapRectangle paramMapRectangle)
  {
    return 111319.49079327358D * paramMapMarker.getGeometry().distance(paramMapRectangle.getGeometry());
  }
  
  public static double distanceBetweenEdges(MapFactory.MapPolygon paramMapPolygon, MapFactory.MapCircle paramMapCircle)
  {
    double d = 111319.49079327358D * paramMapPolygon.getGeometry().distance(createGeometry(paramMapCircle.getCentroid())) - paramMapCircle.Radius();
    if (d < 0.0D) {
      d = 0.0D;
    }
    return d;
  }
  
  public static double distanceBetweenEdges(MapFactory.MapPolygon paramMapPolygon1, MapFactory.MapPolygon paramMapPolygon2)
  {
    return 111319.49079327358D * paramMapPolygon1.getGeometry().distance(paramMapPolygon2.getGeometry());
  }
  
  public static double distanceBetweenEdges(MapFactory.MapPolygon paramMapPolygon, MapFactory.MapRectangle paramMapRectangle)
  {
    return 111319.49079327358D * paramMapPolygon.getGeometry().distance(paramMapRectangle.getGeometry());
  }
  
  public static double distanceBetweenEdges(MapFactory.MapPolygon paramMapPolygon, GeoPoint paramGeoPoint)
  {
    return 111319.49079327358D * paramMapPolygon.getGeometry().distance(createGeometry(paramGeoPoint));
  }
  
  public static double distanceBetweenEdges(MapFactory.MapRectangle paramMapRectangle1, MapFactory.MapRectangle paramMapRectangle2)
  {
    return 111319.49079327358D * paramMapRectangle1.getGeometry().distance(paramMapRectangle2.getGeometry());
  }
  
  public static double distanceBetweenEdges(MapFactory.MapRectangle paramMapRectangle, GeoPoint paramGeoPoint)
  {
    return 111319.49079327358D * paramMapRectangle.getGeometry().distance(createGeometry(paramGeoPoint));
  }
  
  public static Coordinate geoPointToCoordinate(GeoPoint paramGeoPoint)
  {
    return new Coordinate(paramGeoPoint.getLongitude(), paramGeoPoint.getLatitude());
  }
  
  public static LinearRing geoPointsToLinearRing(List<GeoPoint> paramList)
  {
    return FACTORY.createLinearRing(pointsToCoordinates(paramList));
  }
  
  public static GeoPoint getCentroid(List<List<GeoPoint>> paramList, List<List<List<GeoPoint>>> paramList1)
  {
    return jtsPointToGeoPoint(createGeometry(paramList, paramList1).getCentroid());
  }
  
  public static GeoPoint getMidpoint(List<GeoPoint> paramList)
  {
    if (paramList.isEmpty()) {
      return new GeoPoint(0.0D, 0.0D);
    }
    if (paramList.size() == 1) {
      return new GeoPoint((GeoPoint)paramList.get(0));
    }
    return jtsPointToGeoPoint(FACTORY.createLineString(pointsToCoordinates(paramList)).getCentroid());
  }
  
  public static boolean isMultiPolygon(YailList paramYailList)
  {
    return (paramYailList.size() > 0) && (isPolygon((YailList)TypeUtil.castNotNull(paramYailList.get(1), YailList.class, "list")));
  }
  
  public static boolean isPolygon(YailList paramYailList)
  {
    if (paramYailList.size() < 3) {
      return false;
    }
    try
    {
      pointFromYailList((YailList)TypeUtil.castNotNull(paramYailList.get(1), YailList.class, "list"));
      return true;
    }
    catch (DispatchableError localDispatchableError) {}
    return false;
  }
  
  public static boolean isValidLatitude(double paramDouble)
  {
    return (-90.0D <= paramDouble) && (paramDouble <= 90.0D);
  }
  
  public static boolean isValidLongitude(double paramDouble)
  {
    return (-180.0D <= paramDouble) && (paramDouble <= 180.0D);
  }
  
  public static GeoPoint jtsPointToGeoPoint(Point paramPoint)
  {
    return new GeoPoint(paramPoint.getY(), paramPoint.getX());
  }
  
  public static List<List<GeoPoint>> multiPolygonFromYailList(YailList paramYailList)
  {
    ArrayList localArrayList = new ArrayList();
    ListIterator localListIterator = paramYailList.listIterator(1);
    while (localListIterator.hasNext()) {
      localArrayList.add(pointsFromYailList((YailList)TypeUtil.castNotNull(localListIterator.next(), YailList.class, "list")));
    }
    return localArrayList;
  }
  
  public static List<List<List<GeoPoint>>> multiPolygonHolesFromYailList(YailList paramYailList)
  {
    localArrayList = new ArrayList();
    ListIterator localListIterator = paramYailList.listIterator(1);
    int i = 1;
    try
    {
      while (localListIterator.hasNext())
      {
        localArrayList.add(multiPolygonFromYailList((YailList)TypeUtil.castNotNull(localListIterator.next(), YailList.class, "list")));
        i++;
      }
      return localArrayList;
    }
    catch (DispatchableError localDispatchableError)
    {
      throw IterationError.fromError(i, localDispatchableError);
    }
  }
  
  public static List<List<List<GeoPoint>>> multiPolygonHolesToList(JSONArray paramJSONArray)
    throws JSONException
  {
    ArrayList localArrayList = new ArrayList();
    if (paramJSONArray.getJSONArray(0).getJSONArray(0).optJSONArray(0) == null) {
      localArrayList.add(multiPolygonToList(paramJSONArray));
    }
    for (;;)
    {
      return localArrayList;
      for (int i = 0; i < paramJSONArray.length(); i++) {
        localArrayList.add(multiPolygonToList(paramJSONArray.getJSONArray(i)));
      }
    }
  }
  
  public static List<List<GeoPoint>> multiPolygonToList(JSONArray paramJSONArray)
    throws JSONException
  {
    ArrayList localArrayList = new ArrayList();
    if (paramJSONArray.length() == 0) {}
    for (;;)
    {
      return localArrayList;
      if (paramJSONArray.getJSONArray(0).optJSONArray(0) == null)
      {
        localArrayList.add(polygonToList(paramJSONArray));
        return localArrayList;
      }
      for (int i = 0; i < paramJSONArray.length(); i++) {
        localArrayList.add(polygonToList(paramJSONArray.getJSONArray(i)));
      }
    }
  }
  
  public static YailList multiPolygonToYailList(List<List<GeoPoint>> paramList)
  {
    LinkedList localLinkedList = new LinkedList();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext()) {
      localLinkedList.add(pointsListToYailList((List)localIterator.next()));
    }
    return YailList.makeList(localLinkedList);
  }
  
  public static GeoPoint pointFromYailList(YailList paramYailList)
  {
    if (paramYailList.length() < 3)
    {
      Object[] arrayOfObject2 = new Object[2];
      arrayOfObject2[0] = Integer.valueOf(2);
      arrayOfObject2[1] = Integer.valueOf(-1 + paramYailList.length());
      throw new DispatchableError(3409, arrayOfObject2);
    }
    try
    {
      GeoPoint localGeoPoint = coerceToPoint(paramYailList.get(1), paramYailList.get(2));
      return localGeoPoint;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      Object[] arrayOfObject1 = new Object[2];
      arrayOfObject1[0] = paramYailList.get(1);
      arrayOfObject1[1] = paramYailList.get(2);
      throw new DispatchableError(3405, arrayOfObject1);
    }
  }
  
  public static List<GeoPoint> pointsFromYailList(YailList paramYailList)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramYailList.iterator();
    int i = 1;
    localIterator.next();
    while (localIterator.hasNext()) {
      try
      {
        localArrayList.add(pointFromYailList((YailList)TypeUtil.castNotNull(localIterator.next(), YailList.class, "list")));
        i++;
      }
      catch (DispatchableError localDispatchableError)
      {
        throw IterationError.fromError(i, localDispatchableError);
      }
    }
    return localArrayList;
  }
  
  public static YailList pointsListToYailList(List<? extends IGeoPoint> paramList)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext()) {
      localArrayList.add(asYailList((IGeoPoint)localIterator.next()));
    }
    return YailList.makeList(localArrayList);
  }
  
  public static Coordinate[] pointsToCoordinates(List<GeoPoint> paramList)
  {
    boolean bool = ((GeoPoint)paramList.get(0)).equals(paramList.get(-1 + paramList.size()));
    int i = paramList.size();
    if (bool) {}
    Coordinate[] arrayOfCoordinate;
    int k;
    for (int j = 0;; j = 1)
    {
      arrayOfCoordinate = new Coordinate[j + i];
      k = 0;
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        GeoPoint localGeoPoint = (GeoPoint)localIterator.next();
        int m = k + 1;
        arrayOfCoordinate[k] = geoPointToCoordinate(localGeoPoint);
        k = m;
      }
    }
    if (!bool) {
      arrayOfCoordinate[k] = arrayOfCoordinate[0];
    }
    return arrayOfCoordinate;
  }
  
  public static List<GeoPoint> polygonToList(JSONArray paramJSONArray)
    throws JSONException
  {
    ArrayList localArrayList = new ArrayList(paramJSONArray.length());
    if (paramJSONArray.length() < 3) {
      throw new DispatchableError(3404, new Object[] { "Too few points in Polygon, expected 3." });
    }
    int i = 0;
    if (i < paramJSONArray.length())
    {
      JSONArray localJSONArray = paramJSONArray.getJSONArray(i);
      if (localJSONArray.length() < 2) {
        throw new JSONException("Invalid number of dimensions in polygon, expected 2.");
      }
      if (localJSONArray.length() == 2) {
        localArrayList.add(new GeoPoint(localJSONArray.getDouble(0), localJSONArray.getDouble(1)));
      }
      for (;;)
      {
        i++;
        break;
        localArrayList.add(new GeoPoint(localJSONArray.getDouble(0), localJSONArray.getDouble(1), localJSONArray.getDouble(2)));
      }
    }
    return localArrayList;
  }
  
  public static Polygon ringToPolygon(List<GeoPoint> paramList)
  {
    return FACTORY.createPolygon(geoPointsToLinearRing(paramList));
  }
  
  public static Polygon ringToPolygon(List<GeoPoint> paramList, List<List<GeoPoint>> paramList1)
  {
    LinearRing localLinearRing = geoPointsToLinearRing(paramList);
    LinearRing[] arrayOfLinearRing = new LinearRing[paramList1.size()];
    int i = 0;
    Iterator localIterator = paramList1.iterator();
    while (localIterator.hasNext())
    {
      List localList = (List)localIterator.next();
      int j = i + 1;
      arrayOfLinearRing[i] = geoPointsToLinearRing(localList);
      i = j;
    }
    return FACTORY.createPolygon(localLinearRing, arrayOfLinearRing);
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.util.GeometryUtil
 * JD-Core Version:    0.7.0.1
 */