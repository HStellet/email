package com.google.appinventor.components.runtime.util;

import android.text.TextUtils;
import android.util.Log;
import com.google.appinventor.components.runtime.LineString;
import com.google.appinventor.components.runtime.Marker;
import com.google.appinventor.components.runtime.Polygon;
import com.google.common.annotations.VisibleForTesting;
import gnu.lists.FString;
import gnu.lists.LList;
import gnu.lists.Pair;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import org.osmdroid.util.GeoPoint;

public final class GeoJSONUtil
{
  private static final String GEOJSON_COORDINATES = "coordinates";
  private static final String GEOJSON_FEATURE = "Feature";
  private static final String GEOJSON_GEOMETRY = "geometry";
  private static final String GEOJSON_PROPERTIES = "properties";
  private static final String GEOJSON_TYPE = "type";
  private static final int KEY = 1;
  private static final int LATITUDE = 2;
  private static final int LONGITUDE = 1;
  private static final String PROPERTY_ANCHOR_HORIZONTAL = "anchorHorizontal";
  private static final String PROPERTY_ANCHOR_VERTICAL = "anchorVertical";
  private static final String PROPERTY_DESCRIPTION = "description";
  private static final String PROPERTY_DRAGGABLE = "draggable";
  private static final String PROPERTY_FILL = "fill";
  private static final String PROPERTY_HEIGHT = "height";
  private static final String PROPERTY_IMAGE = "image";
  private static final String PROPERTY_INFOBOX = "infobox";
  private static final String PROPERTY_STROKE = "stroke";
  private static final String PROPERTY_STROKE_WIDTH = "stroke-width";
  private static final String PROPERTY_TITLE = "title";
  private static final String PROPERTY_VISIBLE = "visible";
  private static final String PROPERTY_WIDTH = "width";
  private static final Map<String, PropertyApplication> SUPPORTED_PROPERTIES;
  private static final int VALUE = 2;
  private static final Map<String, Integer> colors = new HashMap();
  
  static
  {
    colors.put("black", Integer.valueOf(-16777216));
    colors.put("blue", Integer.valueOf(-16776961));
    colors.put("cyan", Integer.valueOf(-16711681));
    colors.put("darkgray", Integer.valueOf(-12303292));
    colors.put("gray", Integer.valueOf(-7829368));
    colors.put("green", Integer.valueOf(-16711936));
    colors.put("lightgray", Integer.valueOf(-3355444));
    colors.put("magenta", Integer.valueOf(-65281));
    colors.put("orange", Integer.valueOf(-14336));
    colors.put("pink", Integer.valueOf(-20561));
    colors.put("red", Integer.valueOf(-65536));
    colors.put("white", Integer.valueOf(-1));
    colors.put("yellow", Integer.valueOf(-256));
    SUPPORTED_PROPERTIES = new HashMap();
    SUPPORTED_PROPERTIES.put("anchorHorizontal".toLowerCase(), new PropertyApplication()
    {
      public void apply(MapFactory.MapFeature paramAnonymousMapFeature, Object paramAnonymousObject)
      {
        if ((paramAnonymousMapFeature instanceof MapFactory.MapMarker)) {
          ((MapFactory.MapMarker)paramAnonymousMapFeature).AnchorHorizontal(GeoJSONUtil.parseIntegerOrString(paramAnonymousObject));
        }
      }
    });
    SUPPORTED_PROPERTIES.put("anchorVertical".toLowerCase(), new PropertyApplication()
    {
      public void apply(MapFactory.MapFeature paramAnonymousMapFeature, Object paramAnonymousObject)
      {
        if ((paramAnonymousMapFeature instanceof MapFactory.MapMarker)) {
          ((MapFactory.MapMarker)paramAnonymousMapFeature).AnchorHorizontal();
        }
      }
    });
    SUPPORTED_PROPERTIES.put("description", new PropertyApplication()
    {
      public void apply(MapFactory.MapFeature paramAnonymousMapFeature, Object paramAnonymousObject)
      {
        paramAnonymousMapFeature.Description(paramAnonymousObject.toString());
      }
    });
    SUPPORTED_PROPERTIES.put("draggable", new PropertyApplication()
    {
      public void apply(MapFactory.MapFeature paramAnonymousMapFeature, Object paramAnonymousObject)
      {
        paramAnonymousMapFeature.Draggable(GeoJSONUtil.parseBooleanOrString(paramAnonymousObject));
      }
    });
    SUPPORTED_PROPERTIES.put("fill", new PropertyApplication()
    {
      public void apply(MapFactory.MapFeature paramAnonymousMapFeature, Object paramAnonymousObject)
      {
        MapFactory.HasFill localHasFill;
        if ((paramAnonymousMapFeature instanceof MapFactory.HasFill))
        {
          localHasFill = (MapFactory.HasFill)paramAnonymousMapFeature;
          if (!(paramAnonymousObject instanceof Number)) {
            break label37;
          }
        }
        label37:
        for (int i = ((Number)paramAnonymousObject).intValue();; i = GeoJSONUtil.parseColor(paramAnonymousObject.toString()))
        {
          localHasFill.FillColor(i);
          return;
        }
      }
    });
    SUPPORTED_PROPERTIES.put("height", new PropertyApplication()
    {
      public void apply(MapFactory.MapFeature paramAnonymousMapFeature, Object paramAnonymousObject)
      {
        if ((paramAnonymousMapFeature instanceof MapFactory.MapMarker)) {
          ((MapFactory.MapMarker)paramAnonymousMapFeature).Height(GeoJSONUtil.parseIntegerOrString(paramAnonymousObject));
        }
      }
    });
    SUPPORTED_PROPERTIES.put("image", new PropertyApplication()
    {
      public void apply(MapFactory.MapFeature paramAnonymousMapFeature, Object paramAnonymousObject)
      {
        if ((paramAnonymousMapFeature instanceof MapFactory.MapMarker)) {
          ((MapFactory.MapMarker)paramAnonymousMapFeature).ImageAsset(paramAnonymousObject.toString());
        }
      }
    });
    SUPPORTED_PROPERTIES.put("infobox", new PropertyApplication()
    {
      public void apply(MapFactory.MapFeature paramAnonymousMapFeature, Object paramAnonymousObject)
      {
        paramAnonymousMapFeature.EnableInfobox(GeoJSONUtil.parseBooleanOrString(paramAnonymousObject));
      }
    });
    SUPPORTED_PROPERTIES.put("stroke", new PropertyApplication()
    {
      public void apply(MapFactory.MapFeature paramAnonymousMapFeature, Object paramAnonymousObject)
      {
        MapFactory.HasStroke localHasStroke;
        if ((paramAnonymousMapFeature instanceof MapFactory.HasStroke))
        {
          localHasStroke = (MapFactory.HasStroke)paramAnonymousMapFeature;
          if (!(paramAnonymousObject instanceof Number)) {
            break label37;
          }
        }
        label37:
        for (int i = ((Number)paramAnonymousObject).intValue();; i = GeoJSONUtil.parseColor(paramAnonymousObject.toString()))
        {
          localHasStroke.StrokeColor(i);
          return;
        }
      }
    });
    SUPPORTED_PROPERTIES.put("stroke-width", new PropertyApplication()
    {
      public void apply(MapFactory.MapFeature paramAnonymousMapFeature, Object paramAnonymousObject)
      {
        if ((paramAnonymousMapFeature instanceof MapFactory.HasStroke)) {
          ((MapFactory.HasStroke)paramAnonymousMapFeature).StrokeWidth(GeoJSONUtil.parseIntegerOrString(paramAnonymousObject));
        }
      }
    });
    SUPPORTED_PROPERTIES.put("title", new PropertyApplication()
    {
      public void apply(MapFactory.MapFeature paramAnonymousMapFeature, Object paramAnonymousObject)
      {
        paramAnonymousMapFeature.Title(paramAnonymousObject.toString());
      }
    });
    SUPPORTED_PROPERTIES.put("width", new PropertyApplication()
    {
      public void apply(MapFactory.MapFeature paramAnonymousMapFeature, Object paramAnonymousObject)
      {
        if ((paramAnonymousMapFeature instanceof MapFactory.MapMarker)) {
          ((MapFactory.MapMarker)paramAnonymousMapFeature).Width(GeoJSONUtil.parseIntegerOrString(paramAnonymousObject));
        }
      }
    });
    SUPPORTED_PROPERTIES.put("visible", new PropertyApplication()
    {
      public void apply(MapFactory.MapFeature paramAnonymousMapFeature, Object paramAnonymousObject)
      {
        paramAnonymousMapFeature.Visible(GeoJSONUtil.parseBooleanOrString(paramAnonymousObject));
      }
    });
  }
  
  @VisibleForTesting
  static int charToHex(char paramChar)
  {
    if (('0' <= paramChar) && (paramChar <= '9')) {
      return paramChar - '0';
    }
    if (('a' <= paramChar) && (paramChar <= 'f')) {
      return 10 + (paramChar - 'a');
    }
    if (('A' <= paramChar) && (paramChar <= 'F')) {
      return 10 + (paramChar - 'A');
    }
    throw new IllegalArgumentException("Invalid hex character. Expected [0-9A-Fa-f].");
  }
  
  private static MapFactory.MapLineString lineStringFromGeoJSON(MapFactory.MapFeatureContainer paramMapFeatureContainer, YailList paramYailList)
  {
    if (paramYailList.size() < 2) {
      throw new IllegalArgumentException("Too few coordinates supplied in GeoJSON");
    }
    LineString localLineString = new LineString(paramMapFeatureContainer);
    localLineString.Points(swapCoordinates(paramYailList));
    return localLineString;
  }
  
  private static MapFactory.MapMarker markerFromGeoJSON(MapFactory.MapFeatureContainer paramMapFeatureContainer, YailList paramYailList)
  {
    if (paramYailList.length() != 3) {
      throw new IllegalArgumentException("Invalid coordinate supplied in GeoJSON");
    }
    Marker localMarker = new Marker(paramMapFeatureContainer);
    localMarker.Latitude(((Number)paramYailList.get(2)).doubleValue());
    localMarker.Longitude(((Number)paramYailList.get(1)).doubleValue());
    return localMarker;
  }
  
  private static MapFactory.MapPolygon multipolygonFromGeoJSON(MapFactory.MapFeatureContainer paramMapFeatureContainer, YailList paramYailList)
  {
    Polygon localPolygon = new Polygon(paramMapFeatureContainer);
    ArrayList localArrayList1 = new ArrayList();
    ArrayList localArrayList2 = new ArrayList();
    Iterator localIterator = paramYailList.iterator();
    localIterator.next();
    while (localIterator.hasNext())
    {
      YailList localYailList = (YailList)localIterator.next();
      localArrayList1.add(swapCoordinates((YailList)localYailList.get(1)));
      localArrayList2.add(YailList.makeList(swapNestedCoordinates((LList)((Pair)localYailList.getCdr()).getCdr())));
    }
    localPolygon.Points(YailList.makeList(localArrayList1));
    localPolygon.HolePoints(YailList.makeList(localArrayList2));
    return localPolygon;
  }
  
  @VisibleForTesting
  static boolean parseBooleanOrString(Object paramObject)
  {
    if ((paramObject instanceof Boolean)) {
      return ((Boolean)paramObject).booleanValue();
    }
    if ((paramObject instanceof String)) {
      return (!"false".equalsIgnoreCase((String)paramObject)) && (((String)paramObject).length() != 0);
    }
    if ((paramObject instanceof FString)) {
      return parseBooleanOrString(paramObject.toString());
    }
    throw new IllegalArgumentException();
  }
  
  @VisibleForTesting
  static int parseColor(String paramString)
  {
    String str = paramString.toLowerCase();
    Integer localInteger = (Integer)colors.get(str);
    if (localInteger != null) {
      return localInteger.intValue();
    }
    if (str.startsWith("#")) {
      return parseColorHex(str.substring(1));
    }
    if (str.startsWith("&h")) {
      return parseColorHex(str.substring(2));
    }
    return -65536;
  }
  
  @VisibleForTesting
  static int parseColorHex(String paramString)
  {
    int i = 0;
    if (paramString.length() == 3)
    {
      i = -16777216;
      for (int m = 0; m < paramString.length(); m++)
      {
        int n = charToHex(paramString.charAt(m));
        i |= (n | n << 4) << 8 * (2 - m);
      }
    }
    if (paramString.length() == 6)
    {
      i = -16777216;
      for (int k = 0; k < 3; k++) {
        i |= (charToHex(paramString.charAt(k * 2)) << 4 | charToHex(paramString.charAt(1 + k * 2))) << 8 * (2 - k);
      }
    }
    if (paramString.length() == 8) {
      for (int j = 0; j < 4; j++) {
        i |= (charToHex(paramString.charAt(j * 2)) << 4 | charToHex(paramString.charAt(1 + j * 2))) << 8 * (3 - j);
      }
    }
    throw new IllegalArgumentException();
    return i;
  }
  
  @VisibleForTesting
  static int parseIntegerOrString(Object paramObject)
  {
    if ((paramObject instanceof Number)) {
      return ((Number)paramObject).intValue();
    }
    if ((paramObject instanceof String)) {
      return Integer.parseInt((String)paramObject);
    }
    if ((paramObject instanceof FString)) {
      return Integer.parseInt(paramObject.toString());
    }
    throw new IllegalArgumentException();
  }
  
  private static MapFactory.MapPolygon polygonFromGeoJSON(MapFactory.MapFeatureContainer paramMapFeatureContainer, YailList paramYailList)
  {
    Polygon localPolygon = new Polygon(paramMapFeatureContainer);
    Iterator localIterator = paramYailList.iterator();
    localIterator.next();
    localPolygon.Points(swapCoordinates((YailList)localIterator.next()));
    if (localIterator.hasNext()) {
      localPolygon.HolePoints(YailList.makeList(swapNestedCoordinates((LList)((Pair)paramYailList.getCdr()).getCdr())));
    }
    return localPolygon;
  }
  
  private static MapFactory.MapFeature processCoordinates(MapFactory.MapFeatureContainer paramMapFeatureContainer, String paramString, YailList paramYailList)
  {
    if ("Point".equals(paramString)) {
      return markerFromGeoJSON(paramMapFeatureContainer, paramYailList);
    }
    if ("LineString".equals(paramString)) {
      return lineStringFromGeoJSON(paramMapFeatureContainer, paramYailList);
    }
    if ("Polygon".equals(paramString)) {
      return polygonFromGeoJSON(paramMapFeatureContainer, paramYailList);
    }
    if ("MultiPolygon".equals(paramString)) {
      return multipolygonFromGeoJSON(paramMapFeatureContainer, paramYailList);
    }
    throw new IllegalArgumentException();
  }
  
  public static Object processGeoJSONFeature(String paramString, MapFactory.MapFeatureContainer paramMapFeatureContainer, YailList paramYailList)
  {
    String str1 = null;
    YailList localYailList1 = null;
    YailList localYailList2 = null;
    Iterator localIterator = ((LList)paramYailList.getCdr()).iterator();
    while (localIterator.hasNext())
    {
      YailList localYailList3 = (YailList)localIterator.next();
      String str2 = localYailList3.getString(0);
      Object localObject = localYailList3.getObject(1);
      if ("type".equals(str2)) {
        str1 = (String)localObject;
      } else if ("geometry".equals(str2)) {
        localYailList1 = (YailList)localObject;
      } else if ("properties".equals(str2)) {
        localYailList2 = (YailList)localObject;
      } else {
        Log.w(paramString, String.format("Unsupported field \"%s\" in JSON format", new Object[] { str2 }));
      }
    }
    if (!"Feature".equals(str1)) {
      throw new IllegalArgumentException(String.format("Unknown type \"%s\"", new Object[] { str1 }));
    }
    if (localYailList1 == null) {
      throw new IllegalArgumentException("No geometry defined for feature.");
    }
    MapFactory.MapFeature localMapFeature = processGeometry(paramString, paramMapFeatureContainer, localYailList1);
    if (localYailList2 != null) {
      processProperties(paramString, localMapFeature, localYailList2);
    }
    return localMapFeature;
  }
  
  private static MapFactory.MapFeature processGeometry(String paramString, MapFactory.MapFeatureContainer paramMapFeatureContainer, YailList paramYailList)
  {
    String str1 = null;
    YailList localYailList1 = null;
    Iterator localIterator = ((LList)paramYailList.getCdr()).iterator();
    while (localIterator.hasNext())
    {
      YailList localYailList2 = (YailList)localIterator.next();
      String str2 = localYailList2.getString(0);
      Object localObject = localYailList2.getObject(1);
      if ("type".equals(str2)) {
        str1 = (String)localObject;
      } else if ("coordinates".equals(str2)) {
        localYailList1 = (YailList)localObject;
      } else {
        Log.w(paramString, String.format("Unsupported field \"%s\" in JSON format", new Object[] { str2 }));
      }
    }
    if (localYailList1 == null) {
      throw new IllegalArgumentException("No coordinates found in GeoJSON Feature");
    }
    return processCoordinates(paramMapFeatureContainer, str1, localYailList1);
  }
  
  private static void processProperties(String paramString, MapFactory.MapFeature paramMapFeature, YailList paramYailList)
  {
    Iterator localIterator = paramYailList.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if ((localObject instanceof YailList))
      {
        YailList localYailList = (YailList)localObject;
        String str = localYailList.get(1).toString();
        PropertyApplication localPropertyApplication = (PropertyApplication)SUPPORTED_PROPERTIES.get(str.toLowerCase());
        if (localPropertyApplication != null) {
          localPropertyApplication.apply(paramMapFeature, localYailList.get(2));
        } else {
          Log.i(paramString, String.format("Ignoring GeoJSON property \"%s\"", new Object[] { str }));
        }
      }
    }
  }
  
  public static YailList swapCoordinates(YailList paramYailList)
  {
    Iterator localIterator = paramYailList.iterator();
    localIterator.next();
    while (localIterator.hasNext())
    {
      YailList localYailList = (YailList)localIterator.next();
      Object localObject = localYailList.get(1);
      Pair localPair = (Pair)localYailList.getCdr();
      localPair.setCar(localYailList.get(2));
      ((Pair)localPair.getCdr()).setCar(localObject);
    }
    return paramYailList;
  }
  
  public static LList swapNestedCoordinates(LList paramLList)
  {
    for (LList localLList = paramLList; !localLList.isEmpty(); localLList = (LList)((Pair)localLList).getCdr()) {
      swapCoordinates((YailList)localLList.get(0));
    }
    return paramLList;
  }
  
  public static void writeFeaturesAsGeoJSON(List<MapFactory.MapFeature> paramList, String paramString)
    throws IOException
  {
    try
    {
      localPrintStream1 = new PrintStream(new FileOutputStream(paramString));
      try
      {
        FeatureWriter localFeatureWriter = new FeatureWriter(localPrintStream1, null);
        localPrintStream1.print("{\"type\": \"FeatureCollection\", \"features\":[");
        Iterator localIterator = paramList.iterator();
        if (!localIterator.hasNext()) {
          break label132;
        }
        ((MapFactory.MapFeature)localIterator.next()).accept(localFeatureWriter, new Object[0]);
        while (localIterator.hasNext())
        {
          MapFactory.MapFeature localMapFeature = (MapFactory.MapFeature)localIterator.next();
          localPrintStream1.print(',');
          localMapFeature.accept(localFeatureWriter, new Object[0]);
        }
        IOUtils.closeQuietly("GeoJSONUtil", localPrintStream2);
      }
      finally
      {
        localPrintStream2 = localPrintStream1;
      }
    }
    finally
    {
      for (;;)
      {
        PrintStream localPrintStream1;
        label132:
        PrintStream localPrintStream2 = null;
      }
    }
    throw localObject1;
    localPrintStream1.print("]}");
    IOUtils.closeQuietly("GeoJSONUtil", localPrintStream1);
  }
  
  private static final class FeatureWriter
    implements MapFactory.MapFeatureVisitor<Void>
  {
    private final PrintStream out;
    
    private FeatureWriter(PrintStream paramPrintStream)
    {
      this.out = paramPrintStream;
    }
    
    private static boolean hasAltitude(GeoPoint paramGeoPoint)
    {
      return Double.compare(0.0D, paramGeoPoint.getAltitude()) != 0;
    }
    
    private void writeColorProperty(String paramString, int paramInt)
    {
      this.out.print(",\"");
      this.out.print(paramString);
      this.out.print("\":\"&H");
      String str = Integer.toHexString(paramInt);
      for (int i = 8; i > str.length(); i--) {
        this.out.print("0");
      }
      this.out.print(str);
      this.out.print("\"");
    }
    
    private void writeLineGeometry(MapFactory.MapLineString paramMapLineString)
    {
      this.out.print("\"geometry\":{\"type\":\"LineString\",\"coordinates\":[");
      writePoints(paramMapLineString.getPoints());
      this.out.print("]}");
    }
    
    private void writeMultipolygonGeometryNoHoles(MapFactory.MapPolygon paramMapPolygon)
    {
      this.out.print("\"geometry\":{\"type\":\"MultiPolygon\",\"coordinates\":[");
      Iterator localIterator1 = paramMapPolygon.getPoints().iterator();
      Iterator localIterator2 = paramMapPolygon.getHolePoints().iterator();
      for (int i = 1; localIterator1.hasNext(); i = 0)
      {
        if (i == 0) {
          this.out.print(",");
        }
        this.out.print("[");
        writePoints((List)localIterator1.next());
        if (localIterator2.hasNext())
        {
          Iterator localIterator3 = ((List)localIterator2.next()).iterator();
          while (localIterator3.hasNext())
          {
            List localList = (List)localIterator3.next();
            this.out.print(",");
            writePoints(localList);
          }
        }
        this.out.print("]");
      }
      this.out.print("]}");
    }
    
    private void writePointGeometry(GeoPoint paramGeoPoint)
    {
      this.out.print("\"geometry\":{\"type\":\"Point\",\"coordinates\":[");
      this.out.print(paramGeoPoint.getLongitude());
      this.out.print(",");
      this.out.print(paramGeoPoint.getLatitude());
      if (hasAltitude(paramGeoPoint))
      {
        this.out.print(",");
        this.out.print(paramGeoPoint.getAltitude());
      }
      this.out.print("]}");
    }
    
    private void writePoints(List<GeoPoint> paramList)
    {
      int i = 1;
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        GeoPoint localGeoPoint = (GeoPoint)localIterator.next();
        if (i == 0) {
          this.out.print(',');
        }
        this.out.print("[");
        this.out.print(localGeoPoint.getLongitude());
        this.out.print(",");
        this.out.print(localGeoPoint.getLatitude());
        if (hasAltitude(localGeoPoint))
        {
          this.out.print(",");
          this.out.print(localGeoPoint.getAltitude());
        }
        this.out.print("]");
        i = 0;
      }
    }
    
    private void writePolygonGeometry(MapFactory.MapPolygon paramMapPolygon)
    {
      if (paramMapPolygon.getPoints().size() > 1)
      {
        writeMultipolygonGeometryNoHoles(paramMapPolygon);
        return;
      }
      writePolygonGeometryNoHoles(paramMapPolygon);
    }
    
    private void writePolygonGeometryNoHoles(MapFactory.MapPolygon paramMapPolygon)
    {
      this.out.print("\"geometry\":{\"type\":\"Polygon\",\"coordinates\":[");
      writePoints((List)paramMapPolygon.getPoints().get(0));
      if (!paramMapPolygon.getHolePoints().isEmpty())
      {
        Iterator localIterator = ((List)paramMapPolygon.getHolePoints().get(0)).iterator();
        while (localIterator.hasNext())
        {
          List localList = (List)localIterator.next();
          this.out.print(",");
          writePoints(localList);
        }
      }
      this.out.print("]}");
    }
    
    private void writeProperties(MapFactory.HasFill paramHasFill)
    {
      writeColorProperty("fill", paramHasFill.FillColor());
    }
    
    private void writeProperties(MapFactory.HasStroke paramHasStroke)
    {
      writeColorProperty("stroke", paramHasStroke.StrokeColor());
      writeProperty("stroke-width", Integer.valueOf(paramHasStroke.StrokeWidth()));
    }
    
    private void writeProperties(MapFactory.MapFeature paramMapFeature)
    {
      writeProperty("description", paramMapFeature.Description());
      writeProperty("draggable", Boolean.valueOf(paramMapFeature.Draggable()));
      writeProperty("infobox", Boolean.valueOf(paramMapFeature.EnableInfobox()));
      writeProperty("title", paramMapFeature.Title());
      writeProperty("visible", Boolean.valueOf(paramMapFeature.Visible()));
    }
    
    private void writePropertiesHeader(String paramString)
    {
      this.out.print(",\"properties\":{\"$Type\":\"" + paramString + "\"");
    }
    
    private void writeProperty(String paramString, Object paramObject)
    {
      try
      {
        String str = JsonUtil.getJsonRepresentation(paramObject);
        this.out.print(",\"");
        this.out.print(paramString);
        this.out.print("\":");
        this.out.print(str);
        return;
      }
      catch (JSONException localJSONException)
      {
        Log.w("GeoJSONUtil", "Unable to serialize the value of \"" + paramString + "\" as JSON", localJSONException);
      }
    }
    
    private void writeProperty(String paramString1, String paramString2)
    {
      if ((paramString2 == null) || (TextUtils.isEmpty(paramString2))) {
        return;
      }
      writeProperty(paramString1, paramString2);
    }
    
    private void writeType(String paramString)
    {
      this.out.print("\"type\":\"");
      this.out.print(paramString);
      this.out.print("\"");
    }
    
    public Void visit(MapFactory.MapCircle paramMapCircle, Object... paramVarArgs)
    {
      this.out.print("{");
      writeType("Feature");
      this.out.print(',');
      writePointGeometry(paramMapCircle.getCentroid());
      writePropertiesHeader(paramMapCircle.getClass().getName());
      writeProperties(paramMapCircle);
      writeProperties(paramMapCircle);
      writeProperties(paramMapCircle);
      this.out.print("}}");
      return null;
    }
    
    public Void visit(MapFactory.MapLineString paramMapLineString, Object... paramVarArgs)
    {
      this.out.print("{");
      writeType("Feature");
      this.out.print(',');
      writeLineGeometry(paramMapLineString);
      writePropertiesHeader(paramMapLineString.getClass().getName());
      writeProperties(paramMapLineString);
      writeProperties(paramMapLineString);
      this.out.print("}}");
      return null;
    }
    
    public Void visit(MapFactory.MapMarker paramMapMarker, Object... paramVarArgs)
    {
      this.out.print("{");
      writeType("Feature");
      this.out.print(',');
      writePointGeometry(paramMapMarker.getCentroid());
      writePropertiesHeader(paramMapMarker.getClass().getName());
      writeProperties(paramMapMarker);
      writeProperties(paramMapMarker);
      writeProperties(paramMapMarker);
      writeProperty("anchorHorizontal", Integer.valueOf(paramMapMarker.AnchorHorizontal()));
      writeProperty("anchorVertical", Integer.valueOf(paramMapMarker.AnchorVertical()));
      writeProperty("height", Integer.valueOf(paramMapMarker.Height()));
      writeProperty("image", paramMapMarker.ImageAsset());
      writeProperty("width", Integer.valueOf(paramMapMarker.Width()));
      this.out.print("}}");
      return null;
    }
    
    public Void visit(MapFactory.MapPolygon paramMapPolygon, Object... paramVarArgs)
    {
      this.out.print("{");
      writeType("Feature");
      this.out.print(',');
      writePolygonGeometry(paramMapPolygon);
      writePropertiesHeader(paramMapPolygon.getClass().getName());
      writeProperties(paramMapPolygon);
      writeProperties(paramMapPolygon);
      writeProperties(paramMapPolygon);
      this.out.print("}}");
      return null;
    }
    
    public Void visit(MapFactory.MapRectangle paramMapRectangle, Object... paramVarArgs)
    {
      this.out.print("{");
      writeType("Feature");
      this.out.print(",\"geometry\":{\"type\":\"Polygon\",\"coordinates\":[");
      this.out.print("[" + paramMapRectangle.WestLongitude() + "," + paramMapRectangle.NorthLatitude() + "],");
      this.out.print("[" + paramMapRectangle.WestLongitude() + "," + paramMapRectangle.SouthLatitude() + "],");
      this.out.print("[" + paramMapRectangle.EastLongitude() + "," + paramMapRectangle.SouthLatitude() + "],");
      this.out.print("[" + paramMapRectangle.EastLongitude() + "," + paramMapRectangle.NorthLatitude() + "],");
      this.out.print("[" + paramMapRectangle.WestLongitude() + "," + paramMapRectangle.NorthLatitude() + "]]}");
      writePropertiesHeader(paramMapRectangle.getClass().getName());
      writeProperties(paramMapRectangle);
      writeProperties(paramMapRectangle);
      writeProperties(paramMapRectangle);
      writeProperty("NorthLatitude", Double.valueOf(paramMapRectangle.NorthLatitude()));
      writeProperty("WestLongitude", Double.valueOf(paramMapRectangle.WestLongitude()));
      writeProperty("SouthLatitude", Double.valueOf(paramMapRectangle.SouthLatitude()));
      writeProperty("EastLongitude", Double.valueOf(paramMapRectangle.EastLongitude()));
      this.out.print("}}");
      return null;
    }
  }
  
  private static abstract interface PropertyApplication
  {
    public abstract void apply(MapFactory.MapFeature paramMapFeature, Object paramObject);
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.util.GeoJSONUtil
 * JD-Core Version:    0.7.0.1
 */