package com.google.appinventor.components.runtime.util;

import android.telephony.PhoneNumberUtils;
import java.util.Locale;

public final class LollipopUtil
{
  public static String formatNumber(String paramString)
  {
    return PhoneNumberUtils.formatNumber(paramString, Locale.getDefault().getCountry());
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.runtime.util.LollipopUtil
 * JD-Core Version:    0.7.0.1
 */