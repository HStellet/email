package com.google.appinventor.components.annotations.androidmanifest;

import java.lang.annotation.Annotation;

public @interface IntentFilterElement
{
  ActionElement[] actionElements();
  
  CategoryElement[] categoryElements() default {};
  
  DataElement[] dataElements() default {};
  
  String icon() default "";
  
  String label() default "";
  
  String priority() default "";
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.annotations.androidmanifest.IntentFilterElement
 * JD-Core Version:    0.7.0.1
 */