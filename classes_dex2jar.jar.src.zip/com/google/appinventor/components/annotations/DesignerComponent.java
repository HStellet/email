package com.google.appinventor.components.annotations;

import com.google.appinventor.components.common.ComponentCategory;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.TYPE})
public @interface DesignerComponent
{
  int androidMinSdk() default 7;
  
  ComponentCategory category() default ComponentCategory.UNINITIALIZED;
  
  String description() default "";
  
  String designerHelpDescription() default "";
  
  String helpUrl() default "";
  
  String iconName() default "";
  
  boolean nonVisible() default false;
  
  boolean showOnPalette() default true;
  
  int version();
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.annotations.DesignerComponent
 * JD-Core Version:    0.7.0.1
 */