package com.google.appinventor.components.annotations;

public enum PropertyCategory
{
  private String name;
  
  static
  {
    APPEARANCE = new PropertyCategory("APPEARANCE", 1, "Appearance");
    DEPRECATED = new PropertyCategory("DEPRECATED", 2, "Deprecated");
    UNSET = new PropertyCategory("UNSET", 3, "Unspecified");
    PropertyCategory[] arrayOfPropertyCategory = new PropertyCategory[4];
    arrayOfPropertyCategory[0] = BEHAVIOR;
    arrayOfPropertyCategory[1] = APPEARANCE;
    arrayOfPropertyCategory[2] = DEPRECATED;
    arrayOfPropertyCategory[3] = UNSET;
    $VALUES = arrayOfPropertyCategory;
  }
  
  private PropertyCategory(String paramString)
  {
    this.name = paramString;
  }
  
  public String getName()
  {
    return this.name;
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     com.google.appinventor.components.annotations.PropertyCategory
 * JD-Core Version:    0.7.0.1
 */