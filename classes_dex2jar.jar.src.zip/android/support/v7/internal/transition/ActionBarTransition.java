package android.support.v7.internal.transition;

import android.view.ViewGroup;

public class ActionBarTransition
{
  private static final boolean TRANSITIONS_ENABLED = false;
  private static final int TRANSITION_DURATION = 120;
  
  public static void beginDelayedTransition(ViewGroup paramViewGroup) {}
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     android.support.v7.internal.transition.ActionBarTransition
 * JD-Core Version:    0.7.0.1
 */