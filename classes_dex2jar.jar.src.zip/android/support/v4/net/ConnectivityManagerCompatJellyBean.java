package android.support.v4.net;

import android.net.ConnectivityManager;

class ConnectivityManagerCompatJellyBean
{
  public static boolean isActiveNetworkMetered(ConnectivityManager paramConnectivityManager)
  {
    return paramConnectivityManager.isActiveNetworkMetered();
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     android.support.v4.net.ConnectivityManagerCompatJellyBean
 * JD-Core Version:    0.7.0.1
 */