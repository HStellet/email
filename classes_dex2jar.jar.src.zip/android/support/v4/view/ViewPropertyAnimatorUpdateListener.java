package android.support.v4.view;

import android.view.View;

public abstract interface ViewPropertyAnimatorUpdateListener
{
  public abstract void onAnimationUpdate(View paramView);
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     android.support.v4.view.ViewPropertyAnimatorUpdateListener
 * JD-Core Version:    0.7.0.1
 */