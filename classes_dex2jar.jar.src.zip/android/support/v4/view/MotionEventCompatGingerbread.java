package android.support.v4.view;

import android.view.MotionEvent;

class MotionEventCompatGingerbread
{
  public static int getSource(MotionEvent paramMotionEvent)
  {
    return paramMotionEvent.getSource();
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     android.support.v4.view.MotionEventCompatGingerbread
 * JD-Core Version:    0.7.0.1
 */