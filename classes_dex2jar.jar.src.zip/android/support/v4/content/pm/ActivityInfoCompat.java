package android.support.v4.content.pm;

public class ActivityInfoCompat
{
  public static final int CONFIG_UI_MODE = 512;
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     android.support.v4.content.pm.ActivityInfoCompat
 * JD-Core Version:    0.7.0.1
 */