package android.support.v4.app;

abstract interface NotificationBuilderWithActions
{
  public abstract void addAction(NotificationCompatBase.Action paramAction);
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     android.support.v4.app.NotificationBuilderWithActions
 * JD-Core Version:    0.7.0.1
 */