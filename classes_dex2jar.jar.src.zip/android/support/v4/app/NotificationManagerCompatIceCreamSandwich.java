package android.support.v4.app;

class NotificationManagerCompatIceCreamSandwich
{
  static final int SIDE_CHANNEL_BIND_FLAGS = 33;
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     android.support.v4.app.NotificationManagerCompatIceCreamSandwich
 * JD-Core Version:    0.7.0.1
 */