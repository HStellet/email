package android.support.v4.graphics.drawable;

import android.graphics.drawable.Drawable;

class DrawableCompatApi22
{
  public static Drawable wrapForTinting(Drawable paramDrawable)
  {
    return paramDrawable;
  }
}


/* Location:           C:\Users\Dr. S.N. Sachdeva\Desktop\email\dex2jar-0.0.9.15\classes_dex2jar.jar.jar
 * Qualified Name:     android.support.v4.graphics.drawable.DrawableCompatApi22
 * JD-Core Version:    0.7.0.1
 */